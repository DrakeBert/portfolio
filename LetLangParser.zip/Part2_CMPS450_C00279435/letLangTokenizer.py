#! /usr/bin/python
import collections
import re
import letPrograms as pg
Token = collections.namedtuple('Token', ['type', 'value', 'line', 'column'])

def tokenize(code):
    keywords = {'if', 'then', 'for', 'minus', 'else', 'let', 'iszero', 'in'}
    token_specification = [
        ('ASSIGN',   r'='),           # Assignment operator
        ('IDENTIF',  r'[A-Za-z]+'),    # Identifiers
        ('RPAREN',   r'[)]'),
        ('LPAREN',   r'[(]'),
        ('COMMA',    r','),
        ('INTEGER',  r'\d+')
    ]
    tok_regex = '|'.join('(?P<%s>%s)' % pair for pair in token_specification)
    line_num = 1
    line_start = 0
    for mo in re.finditer(tok_regex, code):
        kind = mo.lastgroup
        value = mo.group(kind)
        if kind == 'NEWLINE':
            line_start = mo.end()
            line_num += 1
        elif kind == 'SKIP':
            pass
        elif kind == 'MISMATCH':
            raise RuntimeError('%r unexpected on line %d' % (value, line_num))
        else:
            if kind == 'IDENTIF' and value in keywords:
                kind = value
            column = mo.start() - line_start
            yield Token(kind, value, line_num, column)

statements = '''
    IF quantity THEN
        total := total + price * quantity;
        tax := price * 0.05;
    ENDIF;
'''

#for token in tokenize(statements):
#    print(token)
    
if __name__ == "__main__":
    print("prog1:")
    for token in tokenize(pg.prog1):
        print(token)
        print("\nprog2:")
    for token in tokenize(pg.prog2):
        print(token)
