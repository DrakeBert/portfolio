import letLangTokenizer as tk
import astNd as ast
import letLangParser as parse
import letEnvironment as en
import letPrograms as pg

def evaluate(astNd, env): # returns: instance of <class 'int'>
    astNd.env = env
    if is_let_exp(astNd):
        var = var_of_let_exp(astNd)      # get parts of let-exp
        val = var_val_of_let_exp(astNd)
        body = body_of_let_exp(astNd)
        var_name = var.value
        new_env = en.extend_env(var_name, evaluate(val, env), env)
        final_val = evaluate(body, new_env) # get value for body in new_env
        body.env = new_env
        body.computedVal = final_val
        astNd.computedVal = final_val
        return astNd.computedVal
    elif is_var_exp(astNd):
        final_value = en.apply_env(env, astNd.value)
        astNd.computedVal = final_value
        return astNd.computedVal
    elif is_const_exp(astNd):
        return int(arg_of_const_exp(astNd))
    elif is_diff_exp(astNd):
        first_val = evaluate(arg1_of_diff_exp(astNd), env)
        second_val = evaluate(arg2_of_diff_exp(astNd), env)
        final_value = first_val - second_val
        astNd.computedVal = final_value
        return astNd.computedVal
    elif is_zero_exp(astNd):
        if evaluate(arg_of_zero_exp(astNd), env) == 0:
            astNd.computedVal = 1
            return astNd.computedVal
        else:
            astNd.value = 0
            return astNd.value
    elif is_if_exp(astNd):
        test_val = evaluate(test_of_if_exp(astNd), env)
        if test_val:
            final_val = evaluate(then_action_of_if_exp(astNd), env)
            astNd.computedVal = final_val
            return astNd.computedVal
        else:
            final_val = evaluate(else_action_of_if_exp(astNd), env)
            astNd.computedVal = final_val
            return astNd.computedVal
    else:
        print("from evaluate: Unrecognized language construct!!!")

''' 1. Recognizer and Selectors for let expression '''
def is_let_exp(astNd):
    if type(astNd) == ast.ASTnd and astNd.type == 'let_exp':
        return True
    else:
        return False

def var_of_let_exp(astNd):
    return astNd.children[0]

def var_val_of_let_exp(astNd):
    return astNd.children[1]

def body_of_let_exp(astNd):
    return astNd.children[2]

''' 2. Recognizer and Selectors for if expression '''
def is_if_exp(astNd):
    if type(astNd) == ast.ASTnd and astNd.type == 'if_exp':
        return True
    else:
        return False

def test_of_if_exp(astNd):
    return astNd.children[0]

def then_action_of_if_exp(astNd):
    return astNd.children[1]

def else_action_of_if_exp(astNd):
    return astNd.children[2]

''' 3. Recognizer and Selectors for zero expression '''
def is_zero_exp(astNd):
    if type(astNd) == ast.ASTnd and astNd.type == 'zero_exp':
        return True
    else:
        return False

def arg_of_zero_exp(astNd):
    return astNd.children[0]


''' 4. Recognizer and Selectors for minus expression '''
def is_diff_exp(astNd):
    if type(astNd) == ast.ASTnd and astNd.type == 'diff_exp':
        return True
    else:
        return False

def arg1_of_diff_exp(astNd):
    return astNd.children[0]

def arg2_of_diff_exp(astNd):
    return astNd.children[1]


''' 5. Recognizer and Selectors for number expression '''
def is_const_exp(astNd):
    if type(astNd) == ast.ASTnd and astNd.type == 'const_exp':
        return True
    else:
        return False

def arg_of_const_exp(astNd):
    return astNd.value

''' 6. Recognizer and Selectors for identifier expression '''
def is_var_exp(astNd):
    if type(astNd) == ast.ASTnd and astNd.type == 'var_exp':
        return True
    else:
        return False

def arg_of_var_exp(astNd):
    return astNd.children[0]

def var_val_of_var_exp(astNd):
    return astNd.children[1]

def body_of_var_exp(astNd):
    return astNd.children[2]



if __name__ == "__main__":
    print("-" * 60)
    print("Program: ", pg.prog1)
    AST, remaining = parse.parseExp(tk.tokenize(pg.prog1))
    print("AST before evaluating:")
    AST.printTree() # Prints AST before evaluating
    print("value:", evaluate(AST, en.empty_env()))
    print("\nAST after evaluating:")
    AST.printTree_verbose() # Prints AST before evaluating

    print("-" * 60)    
    print("Program: ", pg.prog9)
    AST, remaining = parse.parseExp(tk.tokenize(pg.prog9))
    print("AST before evaluating:")
    AST.printTree() # Prints AST before evaluating
    print("value:", evaluate(AST, en.empty_env()))
    print("\nAST after evaluating:")
    AST.printTree_verbose() # Prints AST before evaluating

