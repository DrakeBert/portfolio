import letLangTokenizer as tk
import astNd as ast
import itertools
#import pprint
import letPrograms as pg


#pp = pprint.PrettyPrinter(indent=4)
toks = tk.tokenize(pg.prog9)

def peek(iterable):
    try: # throws an exception if at the end of the stream
        first = next(iterable) # "next()" advances to next item
    except StopIteration:
        return None
    return first, itertools.chain([first], iterable)
# 1st is token; 2nd is original seq unchanged

tok = peek(toks)

def parseExp(toks):
    tok = peek(toks)
    if tok == None:
        print("Error")
        return
    else:
        tok, remainingToks = tok # peek returned two values
    tok = next(remainingToks)
    if tok.type == 'INTEGER':
        tree = ast.ASTnd('const_exp', value = tok.value, isterm = True)

    elif tok.type == 'minus':
        next(remainingToks)
        subtree1, remainingToks = parseExp(remainingToks)
        next(remainingToks)
        subtree2, remainingToks = parseExp(remainingToks)
        next(remainingToks)
        tree = ast.ASTnd('diff_exp')
        tree.children.append(subtree1)
        tree.children.append(subtree2)
        #tree = ['diff_exp', ['exp1', subtree1], ['exp2', subtree2]]

    elif tok.type == 'iszero':
        next(remainingToks)
        subtree, remainingToks = parseExp(remainingToks)
        next(remainingToks)
        tree = ast.ASTnd('zero_exp')
        tree.children.append(subtree)

    elif tok.type == 'if':
        subtree1, remainingToks = parseExp(remainingToks)
        next(remainingToks)
        subtree2, remainingToks = parseExp(remainingToks)
        next(remainingToks)
        subtree3, remainingToks = parseExp(remainingToks)
        tree = ast.ASTnd('if_exp')
        tree.children.append(subtree1)
        tree.children.append(subtree2)
        tree.children.append(subtree3)

    elif tok.type == 'IDENTIF':
        tree = ast.ASTnd('var_exp', value = tok.value, isterm = True)

    elif tok.type == 'let':
        subtree1, remainingToks = parseExp(remainingToks)
        next(remainingToks)
        subtree2, remainingToks = parseExp(remainingToks)
        next(remainingToks)
        subtree3, remainingToks = parseExp(remainingToks)
        tree = ast.ASTnd('let_exp')
        tree.children.append(subtree1)
        tree.children.append(subtree2)
        tree.children.append(subtree3)

    else: # case where tok is not one of the above six cases
        print("UNGRAMMATICAL")
        return None, remainingToks
    return tree, remainingToks


if __name__ == "__main__":
    print("prog8:", pg.prog8)
    toks = tk.tokenize(pg.prog8)
    AST, remaining = parseExp(toks)
    print("AST for prog8:")
    AST.printTree()
    #pp.pprint(AST)
    print("prog9:", pg.prog9)
    toks = tk.tokenize(pg.prog9)
    AST, remaining = parseExp(toks)
    print("AST for prog9:")
    AST.printTree()
    #pp.pprint(AST)