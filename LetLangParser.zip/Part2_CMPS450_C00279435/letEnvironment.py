#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 28 11:58:45 2020

@author: maida
"""

# empty_env: () --> Env
def empty_env ():
    return ['empty_env']

# extend_env: Var x val x Env --> Env
def extend_env (var, val, env):
    return ['extend_env', var, val, env]

# apply_env: Env x Var --> Val
def apply_env (env, search_var):
    if env[0] == 'empty_env':
        report_no_binding_found(search_var)
        return
    elif env[0] == 'extend_env':
        saved_var = env[1]
        saved_val = env[2]
        saved_env = env[3]
        if search_var == saved_var:
            return saved_val
        else:
            return apply_env(saved_env, search_var)
    else:
        report_invalid_env(env)
    
def report_no_binding_found (search_var):
    print("Error in apply_env: No binding for {}.".format(search_var))

def report_invalid_env(env):
    print("Error in apply_env: Bad_environment {}".format(env))

def print_env_concise(env):
    print("[", end = '')
    print_env_concise_work(env)
    print("]", end = '')
        
def print_env_concise_work(env):
    if isinstance(env, list) and env[0] == 'extend_env':
        print("(", env[1], ", ", end = '')
        print(env[2], ")", end = '')
        print_env_concise_work(env[3])    

if __name__ == "__main__":
    
    e = extend_env('d', 6,
       extend_env('y', 8,
         extend_env('x', 7,
           extend_env('y', 14,
             empty_env()))))
    
    print("Value of x:", apply_env(e, 'x'))
    print_env_concise(e)
