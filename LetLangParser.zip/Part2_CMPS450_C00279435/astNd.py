import letEnvironment as en

class ASTnd:
    def __init__(self, type, env = None, isterm = False, value = None):
        self.isterm = isterm  # boolean: is it a leaf node?
        self.children = []    # if not a leaf node, will have a list of children
        self.type = type      # Ex: 'diff_exp'
        self.env = env        # Inst of data structure representing an env
        self.value = value    # token value from scanner for constants
        self.computedVal = None  # int value calculated by evaluator

    def printTree(self):
    	self.printTreeWork(0)

    '''
    Each time printTreeWork is called the indentation level increases
    '''
    def printTreeWork(self, indent_level = 0):
        out_string = "    " * indent_level
        print(out_string, self.type, end = '')
        if self.isterm:
            print("  ", self.value)
        else:
            print()
            n = len(self.children)
            for i in range(n):
                self.children[i].printTreeWork(indent_level + 1)
                
    def printTree_verbose(self):
        self.printTreeWork_verbose(0)
        
    def printTreeWork_verbose(self, indent_level = 0):
        out_string = ""
        for i in range(indent_level):
            out_string += "    "
        print(out_string, self.type, end = '')
        #print("  ", self.value,       end = '')
        if isinstance(self.computedVal, int):
            print("  cval:", self.computedVal, end = '')
        print("    en: ", end = '')
        en.print_env_concise(self.env)
        
        n = len(self.children)
        if self.isterm:
            if isinstance(self.value, int):
                pass
                print("")
            else:
                print("  tokVal: ", self.value)
        else:
            print("")
            for i in range(n):
                self.children[i].printTreeWork_verbose(indent_level + 1)
        
            
'''
Example for: if iszero(x) then 1 else 2
'''
if __name__ == "__main__":
    tree = ASTnd('if_exp') # build the top node
    # build subtrees that different subcalls of a parser might supply
    subtree1     = ASTnd('zero_exp')
    subtree1_1   = ASTnd('var_exp', value = 'x', isterm = True)
    subtree1.children.append(subtree1_1)
    subtree2     = ASTnd('const_exp', value = 1, isterm = True)
    subtree3     = ASTnd('const_exp', value = 2, isterm = True)
    tree.children.append(subtree1) # add children to top if-node
    tree.children.append(subtree2)
    tree.children.append(subtree3)
    tree.printTree()
    