#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  2 12:17:58 2021

@author: maida
"""

'''
Below is nine different sample programs to test the parser.
We encode the programs into string variables to avoid the distraction
of writing I/O statements.

To use, import as follows:

import letPrograms as pg
'''

prog0 = "1"
prog1 = "let av = 1 in av"
prog2 = "minus(1, 2)"
prog3 = "minus(minus(1,2), minus(3, 4))"
prog4 = "iszero(29)"
prog5 = "if iszero(10) then minus(1, 2) else minus(2, 1)"
prog6 = "xxx"
prog7 = '''
    let x = 1
    in
        if iszero(x)
        then 1
        else 2
'''
prog8 = '''
    let x = 7
    in let y = 2
       in let y = let x = minus(x, 1)
                  in minus(x, y)
          in minus(minus(x, 8), y)
'''

prog9 = '''
let x = 11
in let y = 20
   in if iszero(minus(x, 11))
       then minus(y, 2)
       else minus(y, 4)
'''
